"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Globe, Check } from "lucide-react"
import Link from "next/link"
import { useEffect, useState, useRef } from "react"
import { PageTitle } from "@/components/page-title"

export default function Home() {
  const pricingRef = useRef(null)

  const scrollToPricing = () => {
    pricingRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <section className="py-20 md:py-28 lg:py-36 relative overflow-hidden rounded-xl">
        <div className="absolute inset-0 z-0">
          <img
            src="/images/header-background.jpg"
            alt="Digital security network background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/70 to-transparent dark:from-gray-950/90 dark:via-gray-900/70"></div>
        </div>

        <div className="container px-4 md:px-6 relative z-10">
          <div className="max-w-2xl text-left">
            <div className="space-y-8">
              <div className="space-y-4">
                <PageTitle>
                  ADAS ONE <br />
                  <span style={{ color: "#0D99FF" }}>Security Operation Center</span>
                </PageTitle>
                <p className="text-muted-foreground text-xs sm:text-sm md:text-sm font-normal max-w-md">
                  全方位的網路安全解決方案，保護您的應用程式免受各種網路威脅
                </p>
              </div>
              <div className="flex flex-wrap gap-4">
                <Link href="/login">
                  <Button
                    className="text-white font-normal px-6 py-2 text-base"
                    style={{ backgroundColor: "#0D99FF", borderColor: "#0D99FF" }}
                    onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#0A85E9")}
                    onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#0D99FF")}
                  >
                    開始使用
                  </Button>
                </Link>
                <Link href="/services">
                  <Button
                    variant="outline"
                    className="font-normal px-6 py-2 text-base border-2 bg-transparent"
                    style={{ borderColor: "#0D99FF", color: "#0D99FF" }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.backgroundColor = "rgba(13, 153, 255, 0.1)"
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.backgroundColor = "transparent"
                    }}
                  >
                    了解更多
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-card rounded-lg shadow-lg border">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12 relative">
            <h2 className="text-3xl font-semibold">
              我們的<span style={{ color: "#0D99FF" }}>服務</span>
            </h2>
            <div className="absolute right-0 top-0">
              <Button
                className="text-white font-normal px-6 py-2"
                style={{ backgroundColor: "#0D99FF", borderColor: "#0D99FF" }}
                onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#0A85E9")}
                onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#0D99FF")}
                onClick={scrollToPricing}
              >
                優惠組合方案
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Link href="/services/hiwaf">
              <AnimatedServiceCard
                title="WAF防禦"
                description="WAF網站應用防火牆服務"
                icon={<Shield className="h-10 w-10" style={{ color: "#0D99FF" }} />}
                delay={0}
                price="$3.5萬"
                priceUnit="/月起"
              />
            </Link>
            <Link href="/services/application-defense">
              <AnimatedServiceCard
                title="應用層DDoS防禦"
                description="防範任何規模或類型的 DDoS 攻擊"
                icon={<Shield className="h-10 w-10" style={{ color: "#0D99FF" }} />}
                delay={100}
                price="$3萬"
                priceUnit="/月起"
                priceNote="計價單位：(應用程式數量/流量)"
              />
            </Link>
            <Link href="/services/cdn">
              <AnimatedServiceCard
                title="全球CDN加速"
                description="通過全球分佈的節點加速內容傳遞，提升用戶體驗。"
                icon={<Globe className="h-10 w-10" style={{ color: "#0D99FF" }} />}
                delay={200}
                price="$3萬"
                priceUnit="/月起"
                priceNote="計價單位: (應用程式數量/流量）"
              />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4">
              <h2 className="text-3xl font-semibold tracking-tighter sm:text-4xl md:text-5xl">
                為什麼選擇 <span style={{ color: "#0D99FF" }}>ADAS ONE</span>
              </h2>
              <p className="text-muted-foreground md:text-lg font-normal">
                7x24 專業團隊，監控掌握企業資安狀態，即時通知資安威脅
              </p>
              <ul className="space-y-2 text-muted-foreground font-normal">
                <li className="flex items-center">
                  <div className="mr-2 h-3 w-3 rounded-full" style={{ backgroundColor: "#5591BD" }} />
                  全天候監控和保護
                </li>
                <li className="flex items-center">
                  <div className="mr-2 h-3 w-3 rounded-full" style={{ backgroundColor: "#5591BD" }} />
                  易於部署和管理
                </li>
                <li className="flex items-center">
                  <div className="mr-2 h-3 w-3 rounded-full" style={{ backgroundColor: "#5591BD" }} />
                  靈活的定價方案
                </li>
                <li className="flex items-center">
                  <div className="mr-2 h-3 w-3 rounded-full" style={{ backgroundColor: "#5591BD" }} />
                  專業的技術支持
                </li>
              </ul>
            </div>
            <div className="flex justify-center">
              <div className="w-full max-w-md rounded-lg bg-card p-8 h-80 flex items-center justify-center shadow-lg border">
                <p className="text-muted-foreground text-center">安全統計圖表展示區</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 優惠組合方案區塊 */}
      <section ref={pricingRef} className="py-12 md:py-24 bg-card rounded-lg shadow-lg border">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-semibold tracking-tighter sm:text-4xl md:text-5xl">
              優惠<span style={{ color: "#0D99FF" }}>組合方案</span>
            </h2>
            <p className="mt-4 text-muted-foreground max-w-2xl mx-auto font-normal">
              為您提供全方位的網路安全保護
            </p>
          </div>

          <div className="flex justify-center">
            <div className="max-w-md w-full">
              <Card className="bg-card border-border shadow-lg ring-2 ring-blue-600 shadow-xl">
                <CardHeader className="pb-0">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl font-medium text-card-foreground">優惠價</CardTitle>
                      <CardDescription className="font-normal text-muted-foreground">
                        WAF防禦 + 應用層DDoS防禦 + 全球CDN加速
                      </CardDescription>
                    </div>
                    <div className="bg-blue-600 text-white text-xs px-3 py-1 rounded-full font-medium">推薦</div>
                  </div>
                  <div className="mt-4">
                    <div className="flex items-baseline gap-1">
                      <span className="text-muted-foreground font-normal">$</span>
                      <span className="text-3xl font-medium text-card-foreground">5萬</span>
                      <span className="text-muted-foreground font-normal">/月起</span>
                      <span className="text-sm text-muted-foreground line-through font-normal">原價$7.5萬</span>
                    </div>
                  </div>
                </CardHeader>

                <div className="px-6 py-6">
                  <Button
                    className="w-full text-white font-normal"
                    style={{ backgroundColor: "#0D99FF", borderColor: "#0D99FF" }}
                    onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#0A85E9")}
                    onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#0D99FF")}
                  >
                    選擇優惠組合
                  </Button>
                </div>

                <CardContent className="pt-0">
                  <ul className="space-y-3">
                    <li className="flex items-center">
                      <Check className="h-5 w-5 mr-2 flex-shrink-0" style={{ color: "#0D99FF" }} />
                      <span className="text-muted-foreground font-normal">WAF 網站應用防火牆</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-5 w-5 mr-2 flex-shrink-0" style={{ color: "#0D99FF" }} />
                      <span className="text-muted-foreground font-normal">應用層 DDoS 防禦</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-5 w-5 mr-2 flex-shrink-0" style={{ color: "#0D99FF" }} />
                      <span className="text-muted-foreground font-normal">全球 CDN 加速服務</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-5 w-5 mr-2 flex-shrink-0" style={{ color: "#0D99FF" }} />
                      <span className="text-muted-foreground font-normal">乾淨流量 10TB</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-5 w-5 mr-2 flex-shrink-0" style={{ color: "#0D99FF" }} />
                      <span className="text-muted-foreground font-normal">應用程式 1個</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-5 w-5 mr-2 flex-shrink-0" style={{ color: "#0D99FF" }} />
                      <span className="text-muted-foreground font-normal">7x24 專業技術支援</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-16 text-center">
            <h3 className="text-2xl font-medium text-foreground mb-4">需要自定義方案？</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-6 font-normal">
              我們提供靈活的自定義方案，以滿足您的特定需求。聯繫我們的銷售團隊，獲取專屬方案。
            </p>
            <Button
              className="text-white font-normal"
              style={{ backgroundColor: "#0D99FF", borderColor: "#0D99FF" }}
              onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#0A85E9")}
              onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#0D99FF")}
            >
              聯繫我們
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

function AnimatedServiceCard({ title, description, icon, delay = 0, price, priceUnit, priceNote }) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, delay)

    return () => clearTimeout(timer)
  }, [delay])

  return (
    <div
      className={`transform transition-all duration-700 ease-out ${
        isVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
      }`}
    >
      <Card className="border hover:border-primary/50 transition-all duration-300 shadow-lg bg-card relative h-[280px] flex flex-col hover:shadow-xl">
        <CardHeader className="flex flex-row items-center gap-4 pb-3">
          <div className="transform transition-all duration-500 hover:scale-110">{icon}</div>
          <div className="flex-1">
            <CardTitle className="text-xl font-medium">{title}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="pt-0 flex flex-col flex-1">
          <CardDescription className="text-muted-foreground font-normal mb-4 line-clamp-3 h-[72px]">
            {description}
          </CardDescription>
          <div className="mt-auto">
            {price && (
              <div className="mt-4">
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold" style={{ color: "#0D99FF" }}>
                    {price}
                  </span>
                  <span className="text-sm text-muted-foreground font-normal">{priceUnit}</span>
                </div>
                {priceNote && <p className="text-xs text-muted-foreground font-normal mt-1">{priceNote}</p>}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
