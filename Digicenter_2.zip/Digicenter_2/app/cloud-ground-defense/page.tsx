"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Shield, Cloud, Server, CheckCircle, ArrowRight, Users, TrendingUp, Award } from "lucide-react"
import Link from "next/link"
import { useTheme } from "next-themes"
import { useEffect, useState } from "react"

export default function CloudGroundDefensePage() {
  const { theme, systemTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const currentTheme = mounted ? (theme === "system" ? systemTheme : theme) : "light"
  const isDark = currentTheme === "dark"

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <Badge variant="outline" className="mb-4 text-sm font-normal">
          企業級安全解決方案
        </Badge>
        <h1 className="text-4xl font-semibold tracking-tighter sm:text-5xl md:text-6xl mb-6">
          雲地<span style={{ color: "#0D99FF" }}>雙層式</span>防禦方案
        </h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8 font-normal">
          結合 Cloudflare 雲端防護與 F5 地端設備，打造多層次安全防護體系， 為您的企業提供全方位的網路安全保障
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/account/purchase">
            <Button
              size="lg"
              className="text-white font-normal px-8"
              style={{ backgroundColor: "#0D99FF", borderColor: "#0D99FF" }}
              onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#0A85E9")}
              onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#0D99FF")}
            >
              立即購買
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
          <Button variant="outline" size="lg" className="font-normal px-8 bg-transparent">
            了解更多
          </Button>
        </div>
      </div>

      {/* Architecture Diagram */}
      <div className="mb-16">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-semibold mb-4">雲地雙層式防禦架構圖</h2>
          <p className="text-muted-foreground font-normal">完整的安全防護流程，從雲端到地端的全方位保護</p>
        </div>
        <div className="flex justify-center">
          <div className="w-full max-w-6xl">
            <img
              src={
                isDark ? "/images/cloud-ground-defense-diagram-dark.jpg" : "/images/cloud-ground-defense-diagram.jpg"
              }
              alt="雲地雙層式防禦架構圖"
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold mb-4">核心優勢</h2>
          <p className="text-muted-foreground font-normal">雙重防護機制，確保您的業務安全無虞</p>
        </div>

        <Tabs defaultValue="cloud" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="cloud" className="font-normal">
              <Cloud className="mr-2 h-4 w-4" />
              雲端防護
            </TabsTrigger>
            <TabsTrigger value="ground" className="font-normal">
              <Server className="mr-2 h-4 w-4" />
              地端防護
            </TabsTrigger>
          </TabsList>

          <TabsContent value="cloud">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="shadow-lg">
                <CardHeader>
                  <Shield className="h-8 w-8 mb-2" style={{ color: "#0D99FF" }} />
                  <CardTitle className="font-medium">DDoS 防護</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="font-normal">
                    無限量級防護，抵禦各種規模的 DDoS 攻擊，確保服務持續可用
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <Shield className="h-8 w-8 mb-2" style={{ color: "#0D99FF" }} />
                  <CardTitle className="font-medium">WAF 防護</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="font-normal">
                    Web 應用防火牆，防禦 SQL 注入、XSS 等常見網路攻擊
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <Shield className="h-8 w-8 mb-2" style={{ color: "#0D99FF" }} />
                  <CardTitle className="font-medium">Bot 防護</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="font-normal">智能識別惡意機器人，保護網站免受自動化攻擊</CardDescription>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="ground">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="shadow-lg">
                <CardHeader>
                  <Server className="h-8 w-8 mb-2" style={{ color: "#0D99FF" }} />
                  <CardTitle className="font-medium">F5 負載均衡</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="font-normal">
                    高效能負載均衡，確保應用程式的高可用性和效能
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <Server className="h-8 w-8 mb-2" style={{ color: "#0D99FF" }} />
                  <CardTitle className="font-medium">應用層防護</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="font-normal">深度封包檢測，提供應用層級的安全防護</CardDescription>
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <Server className="h-8 w-8 mb-2" style={{ color: "#0D99FF" }} />
                  <CardTitle className="font-medium">SSL 卸載</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="font-normal">減輕後端伺服器負擔，提升整體系統效能</CardDescription>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Customer Cases */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold mb-4">客戶成功案例</h2>
          <p className="text-muted-foreground font-normal">看看其他企業如何透過我們的解決方案提升安全性</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <CardTitle className="font-medium">金融服務公司</CardTitle>
                  <p className="text-sm text-muted-foreground">大型銀行</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription className="font-normal mb-4">
                部署雲地雙層防護後，成功阻擋了 99.9% 的惡意攻擊， 系統可用性提升至 99.99%
              </CardDescription>
              <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                <TrendingUp className="h-4 w-4" />
                <span className="text-sm font-medium">攻擊阻擋率 +99.9%</span>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                  <Award className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <CardTitle className="font-medium">電商平台</CardTitle>
                  <p className="text-sm text-muted-foreground">知名購物網站</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription className="font-normal mb-4">
                在雙11購物節期間，成功抵禦大規模 DDoS 攻擊， 確保購物體驗順暢無阻
              </CardDescription>
              <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                <CheckCircle className="h-4 w-4" />
                <span className="text-sm font-medium">零停機時間</span>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                  <Shield className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <CardTitle className="font-medium">政府機關</CardTitle>
                  <p className="text-sm text-muted-foreground">公共服務網站</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription className="font-normal mb-4">
                強化資安防護等級，符合政府資安規範， 保護民眾個資安全
              </CardDescription>
              <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                <Award className="h-4 w-4" />
                <span className="text-sm font-medium">資安等級 A+</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Customized Solutions */}
      <div className="mb-16">
        <Card className="shadow-lg bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-200 dark:border-blue-800">
          <CardContent className="p-8">
            <div className="text-center">
              <h2 className="text-3xl font-semibold mb-4">客製化解決方案</h2>
              <p className="text-muted-foreground mb-8 font-normal max-w-2xl mx-auto">
                我們的專業團隊將根據您的業務需求，設計最適合的安全防護方案， 確保您的企業在數位轉型過程中安全無虞
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="text-white font-normal px-8"
                  style={{ backgroundColor: "#0D99FF", borderColor: "#0D99FF" }}
                  onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#0A85E9")}
                  onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#0D99FF")}
                >
                  免費諮詢
                </Button>
                <Button variant="outline" size="lg" className="font-normal px-8 bg-transparent">
                  下載白皮書
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* CTA Section */}
      <div className="text-center">
        <Card className="shadow-lg">
          <CardContent className="p-8">
            <h2 className="text-2xl font-semibold mb-4">準備開始了嗎？</h2>
            <p className="text-muted-foreground mb-6 font-normal">
              立即部署雲地雙層式防禦方案，為您的企業建立堅實的安全防線
            </p>
            <Link href="/account/purchase">
              <Button
                size="lg"
                className="text-white font-normal px-8"
                style={{ backgroundColor: "#0D99FF", borderColor: "#0D99FF" }}
                onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#0A85E9")}
                onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#0D99FF")}
              >
                立即購買方案
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
