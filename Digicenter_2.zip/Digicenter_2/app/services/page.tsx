"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Zap, Globe } from "lucide-react"
import Link from "next/link"

export default function ServicesPage() {
  const services = [
    {
      title: "WAF防禦",
      description: "網站應用防火牆，保護您的網站免受各種網路攻擊威脅，包括SQL注入、XSS攻擊等。",
      icon: <Shield className="h-8 w-8" />,
      features: ["SQL注入防護", "XSS攻擊防護", "CSRF防護", "實時監控"],
      href: "/services/hiwaf",
      manageHref: "/services/hiwaf/manage",
      subscribed: true,
    },
    {
      title: "應用層DDoS防禦",
      description: "專業的DDoS攻擊防護，確保您的服務在攻擊下仍能正常運行。",
      icon: <Globe className="h-8 w-8" />,
      features: ["多層防護", "智能識別", "自動緩解", "實時報告"],
      href: "/services/application-defense",
      manageHref: "/services/application-defense/manage",
      subscribed: true,
    },
    {
      title: "全球CDN加速",
      description: "全球內容傳遞網路，加速您的網站載入速度，提升用戶體驗。",
      icon: <Zap className="h-8 w-8" />,
      features: ["全球節點", "智能路由", "快取優化", "SSL加速"],
      href: "/services/cdn",
      manageHref: "/services/cdn/manage",
      subscribed: true,
    },
  ]

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Page Title */}
      <div className="text-center mb-16">
        <h1 className="text-3xl font-semibold tracking-tighter sm:text-4xl md:text-5xl">
          我們的<span style={{ color: "#0D99FF" }}>服務</span>
        </h1>
        <p className="mt-4 text-muted-foreground text-lg font-normal max-w-2xl mx-auto">
          全面的網路安全和性能優化解決方案，保護您的數位資產並提升用戶體驗
        </p>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((service, index) => (
          <Card
            key={index}
            className={`relative shadow-lg hover:shadow-xl transition-all duration-300 bg-card border-2 ${
              service.subscribed
                ? "border-green-500 dark:border-green-400 hover:border-green-400 dark:hover:border-green-300"
                : "border-border hover:border-primary"
            }`}
          >
            {service.subscribed && (
              <Badge className="absolute top-4 right-4 bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded-full text-xs font-medium shadow-md z-10">
                已訂閱
              </Badge>
            )}
            <CardHeader>
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 rounded-lg bg-primary/10 dark:bg-primary/20" style={{ color: "#0D99FF" }}>
                  {service.icon}
                </div>
                <CardTitle className="text-xl text-foreground">{service.title}</CardTitle>
              </div>
              <CardDescription className="text-muted-foreground leading-relaxed">{service.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center text-sm text-muted-foreground">
                      <div
                        className="w-1.5 h-1.5 rounded-full bg-primary mr-2 flex-shrink-0"
                        style={{ backgroundColor: "#0D99FF" }}
                      ></div>
                      {feature}
                    </div>
                  ))}
                </div>
                <div className="flex gap-2 pt-4">
                  <Button
                    asChild
                    variant="outline"
                    size="sm"
                    className="flex-1 font-normal bg-transparent border-border hover:bg-accent"
                  >
                    <Link href={service.href}>了解更多</Link>
                  </Button>
                  {service.subscribed ? (
                    <Button
                      asChild
                      size="sm"
                      className="flex-1 font-normal bg-green-600 hover:bg-green-700 text-white border-0 shadow-sm"
                    >
                      <Link href={service.manageHref}>管理服務</Link>
                    </Button>
                  ) : (
                    <Button
                      asChild
                      size="sm"
                      className="flex-1 font-normal shadow-sm"
                      style={{ backgroundColor: "#0D99FF", borderColor: "#0D99FF" }}
                      onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#0A85E9")}
                      onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#0D99FF")}
                    >
                      <Link href={service.href}>立即開始</Link>
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
