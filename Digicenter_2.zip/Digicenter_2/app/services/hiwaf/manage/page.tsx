"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Shield,
  Globe,
  Settings,
  ChevronRight,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Eye,
  Server,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Ban,
  CheckCircle2,
  Flag,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart as RechartsLineChart,
  Line,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from "recharts"
import React from "react"
import { Switch } from "@/components/ui/switch"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Checkbox } from "@/components/ui/checkbox"

type RuleType = "blacklist" | "whitelist" | "country"

interface Rule {
  id: string
  type: RuleType
  value: string
  enabled: boolean
}

const initialRules: Rule[] = [
  { id: "1", type: "blacklist", value: "192.0.2.1", enabled: true },
  { id: "2", type: "whitelist", value: "203.0.113.10", enabled: true },
  { id: "3", type: "country", value: "CN", enabled: true },
]

export default function WAFManagePage() {
  const [domainInput, setDomainInput] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSubdomainDialogOpen, setIsSubdomainDialogOpen] = useState(false)
  const [isWafPolicyDialogOpen, setIsWafPolicyDialogOpen] = useState(false)
  const [selectedMainDomain, setSelectedMainDomain] = useState("")
  const [subdomainInput, setSubdomainInput] = useState("")
  const [copiedField, setCopiedField] = useState("")
  const [expandedTxtRecords, setExpandedTxtRecords] = useState({})
  const [expandedEditForms, setExpandedEditForms] = useState({})
  const [editingDomain, setEditingDomain] = useState(null)
  const [countryAccessMode, setCountryAccessMode] = useState("block") // 新增：國家訪問控制模式

  // WAF 政策相關狀態
  const [blacklistInput, setBlacklistInput] = useState("")
  const [whitelistInput, setWhitelistInput] = useState("")
  const [selectedCountries, setSelectedCountries] = useState([])
  const [selectedSubdomains, setSelectedSubdomains] = useState([]) // 新增：選中的子域名
  const [blacklist, setBlacklist] = useState([
    { id: 1, value: "192.168.1.100", type: "IP" },
    { id: 2, value: "malicious-site.com", type: "域名" },
  ])
  const [whitelist, setWhitelist] = useState([
    { id: 1, value: "203.0.113.0/24", type: "IP段" },
    { id: 2, value: "trusted-partner.com", type: "域名" },
  ])
  const [blockedCountries, setBlockedCountries] = useState([
    { code: "CN", name: "中國" },
    { code: "RU", name: "俄羅斯" },
  ])

  const [configuredDomains, setConfiguredDomains] = useState([
    {
      name: "example.com",
      type: "主域名",
      status: "防護中",
      protocol: "HTTPS",
      txtRecord: {
        type: "TXT",
        name: "_waf-verification.example.com",
        content: "waf-verify-abc123def456ghi789jkl012mno345pqr678stu901vwx234yz",
      },
    },
    { name: "api.example.com", type: "子域名", status: "防護中", protocol: "HTTPS" },
    { name: "admin.example.com", type: "子域名", status: "設定中", protocol: "HTTPS" },
  ])

  // 國家列表
  const countries = [
    { code: "CN", name: "中國" },
    { code: "RU", name: "俄羅斯" },
    { code: "KP", name: "北韓" },
    { code: "IR", name: "伊朗" },
    { code: "US", name: "美國" },
    { code: "JP", name: "日本" },
    { code: "KR", name: "韓國" },
    { code: "GB", name: "英國" },
    { code: "DE", name: "德國" },
    { code: "FR", name: "法國" },
  ]

  const [recordType, setRecordType] = useState("A")
  const [ipv4Address, setIpv4Address] = useState("")
  const [proxyStatus, setProxyStatus] = useState(true)
  const [rules, setRules] = useState<Rule[]>(initialRules)

  const toggleRule = (id: string) =>
    setRules((prev) => prev.map((rule) => (rule.id === id ? { ...rule, enabled: !rule.enabled } : rule)))

  const renderTable = (type: RuleType, title: string) => (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-8" />
              <TableHead>{"規則值"}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rules
              .filter((rule) => rule.type === type)
              .map((rule) => (
                <TableRow key={rule.id}>
                  <TableCell className="w-8">
                    <Checkbox
                      checked={rule.enabled}
                      onCheckedChange={() => toggleRule(rule.id)}
                      aria-label={`${rule.value} enabled`}
                    />
                  </TableCell>
                  <TableCell>{rule.value}</TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
        <div className="mt-4 flex justify-end">
          <Button size="sm">{`新增${title}規則`}</Button>
        </div>
      </CardContent>
    </Card>
  )

  const generateTxtRecord = (domain) => {
    const randomString =
      Math.random().toString(36).substring(2, 15) +
      Math.random().toString(36).substring(2, 15) +
      Math.random().toString(36).substring(2, 15)
    return {
      type: "TXT",
      name: `_waf-verification.${domain}`,
      content: `waf-verify-${randomString}`,
    }
  }

  const handleDomainSubmit = () => {
    if (domainInput.trim()) {
      const newDomain = {
        name: domainInput.trim(),
        type: "主域名",
        status: "防護中",
        protocol: "HTTPS",
        txtRecord: generateTxtRecord(domainInput.trim()),
      }
      setConfiguredDomains((prev) => [...prev, newDomain])
      setDomainInput("")
      setIsDialogOpen(false)
    }
  }

  const handleSubdomainSubmit = () => {
    if (subdomainInput.trim() && selectedMainDomain && ipv4Address.trim()) {
      const newSubdomain = {
        name: `${subdomainInput.trim()}.${selectedMainDomain}`,
        type: "子域名",
        status: "防護中",
        protocol: "HTTPS",
        recordType: recordType,
        ipAddress: ipv4Address.trim(),
        proxy: proxyStatus,
      }
      setConfiguredDomains((prev) => [...prev, newSubdomain])
      setSubdomainInput("")
      setSelectedMainDomain("")
      setRecordType("A")
      setIpv4Address("")
      setProxyStatus(true)
      setIsSubdomainDialogOpen(false)
    }
  }

  const copyToClipboard = (text, field) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedField(field)
      setTimeout(() => setCopiedField(""), 2000)
    })
  }

  const toggleTxtRecord = (domainName) => {
    setExpandedTxtRecords((prev) => ({
      ...prev,
      [domainName]: !prev[domainName],
    }))
  }

  // WAF 政策相關函數
  const addToBlacklist = () => {
    if (blacklistInput.trim()) {
      const newItem = {
        id: Date.now(),
        value: blacklistInput.trim(),
        type: blacklistInput.includes(".") && !blacklistInput.includes("/") ? "域名" : "IP",
      }
      setBlacklist((prev) => [...prev, newItem])
      setBlacklistInput("")
    }
  }

  const addToWhitelist = () => {
    if (whitelistInput.trim()) {
      const newItem = {
        id: Date.now(),
        value: whitelistInput.trim(),
        type: whitelistInput.includes("/")
          ? "IP段"
          : whitelistInput.includes(".") && !whitelistInput.includes("/")
            ? "域名"
            : "IP",
      }
      setWhitelist((prev) => [...prev, newItem])
      setWhitelistInput("")
    }
  }

  const removeFromBlacklist = (id) => {
    setBlacklist((prev) => prev.filter((item) => item.id !== id))
  }

  const removeFromWhitelist = (id) => {
    setWhitelist((prev) => prev.filter((item) => item.id !== id))
  }

  const addBlockedCountry = (countryCode) => {
    const country = countries.find((c) => c.code === countryCode)
    if (country && !blockedCountries.find((c) => c.code === countryCode)) {
      const newCountry = {
        ...country,
      }
      setBlockedCountries((prev) => [...prev, newCountry])
    }
  }

  const removeBlockedCountry = (countryCode) => {
    setBlockedCountries((prev) => prev.filter((country) => country.code !== countryCode))
  }

  const toggleEditForm = (domainName) => {
    setExpandedEditForms((prev) => ({
      ...prev,
      [domainName]: !prev[domainName],
    }))

    if (!expandedEditForms[domainName]) {
      // 設置編輯中的域名數據
      const domain = subdomains.find((d) => d.name === domainName)
      if (domain) {
        setEditingDomain({
          originalName: domain.name,
          name: domain.name.split(".")[0], // 取子域名前綴
          recordType: domain.recordType || "A",
          ipAddress: domain.ipAddress || "",
          proxy: domain.proxy !== undefined ? domain.proxy : true,
          ttl: domain.ttl || "auto",
        })
      }
    }
  }

  const handleEditSubmit = (originalName) => {
    if (editingDomain) {
      setConfiguredDomains((prev) =>
        prev.map((domain) =>
          domain.name === originalName
            ? {
                ...domain,
                recordType: editingDomain.recordType,
                ipAddress: editingDomain.ipAddress,
                proxy: editingDomain.proxy,
                ttl: editingDomain.ttl,
              }
            : domain,
        ),
      )

      // 關閉編輯表單
      setExpandedEditForms((prev) => ({
        ...prev,
        [originalName]: false,
      }))
      setEditingDomain(null)
    }
  }

  const handleDeleteDomain = (domainName) => {
    setConfiguredDomains((prev) => prev.filter((domain) => domain.name !== domainName))
  }

  // 獲取所有主域名
  const mainDomains = configuredDomains.filter((domain) => domain.type === "主域名")
  const subdomains = configuredDomains.filter((domain) => domain.type === "子域名")

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
          <Link href="/services" className="hover:text-primary">
            服務總覽
          </Link>
          <ChevronRight className="h-4 w-4" />
          <Link href="/services/hiwaf" className="hover:text-primary">
            WAF防禦
          </Link>
          <ChevronRight className="h-4 w-4" />
          <span>管理服務</span>
        </div>
        <h1 className="text-3xl font-semibold tracking-tighter">
          WAF防禦<span style={{ color: "#0D99FF" }}>管理</span>
        </h1>
        <p className="mt-2 text-muted-foreground">管理您的網站應用防火牆設定，保護您的網站免受各種網路攻擊威脅</p>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">服務狀態</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">正常運行</div>
            <p className="text-xs text-muted-foreground">99.9% 可用性</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">防護域名</CardTitle>
            <Globe className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{configuredDomains.length}</div>
            <p className="text-xs text-muted-foreground">已配置域名數量</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">今日攔截</CardTitle>
            <Shield className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,247</div>
            <p className="text-xs text-muted-foreground">攻擊請求已攔截</p>
          </CardContent>
        </Card>
      </div>

      {/* WAF Settings */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" style={{ color: "#0D99FF" }} />
              WAF 設定
            </CardTitle>
            <CardDescription>配置您的網站應用防火牆設定，包括域名管理和安全政策</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* 主域名設定 */}
            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Globe className="h-5 w-5 text-blue-500" />
                  <div>
                    <h3 className="font-medium">主域名設定</h3>
                    <p className="text-sm text-muted-foreground">配置主要域名的WAF防護設定</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    {mainDomains.length}個已配置
                  </Badge>
                  <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        設定
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>主域名設定</DialogTitle>
                        <DialogDescription>請輸入您要配置WAF防護的主域名</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="domain" className="text-right">
                            域名
                          </Label>
                          <Input
                            id="domain"
                            placeholder="例如: example.com"
                            value={domainInput}
                            onChange={(e) => setDomainInput(e.target.value)}
                            className="col-span-3"
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button type="submit" onClick={handleDomainSubmit} disabled={!domainInput.trim()}>
                          送出
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              {/* 主域名列表 */}
              {mainDomains.length > 0 && (
                <div className="ml-8 space-y-4">
                  {mainDomains.map((domain, index) => (
                    <div key={index} className="space-y-3">
                      {/* 域名信息 */}
                      <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                        <div className="flex items-center gap-3">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <div>
                            <p className="font-medium">{domain.name}</p>
                            <p className="text-sm text-muted-foreground">{domain.type}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {/* TXT 記錄展開/收合按鈕 */}
                          {domain.txtRecord && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleTxtRecord(domain.name)}
                              className="h-8 w-8 p-0"
                            >
                              {expandedTxtRecords[domain.name] ? (
                                <ChevronUp className="h-4 w-4" />
                              ) : (
                                <ChevronDown className="h-4 w-4" />
                              )}
                            </Button>
                          )}
                        </div>
                      </div>

                      {/* TXT 記錄 - 可收合 */}
                      {domain.txtRecord && expandedTxtRecords[domain.name] && (
                        <div className="ml-4 p-4 border rounded-lg bg-blue-50 dark:bg-blue-950/30 animate-in slide-in-from-top-2 duration-200">
                          <h4 className="font-medium text-sm mb-3 text-blue-700 dark:text-blue-300">
                            DNS TXT 記錄設定
                          </h4>
                          <div className="space-y-3">
                            <div className="grid grid-cols-4 items-center gap-2">
                              <Label className="text-sm font-medium">記錄類型:</Label>
                              <div className="col-span-2 flex items-center gap-2">
                                <code className="px-2 py-1 bg-muted rounded text-sm font-mono">
                                  {domain.txtRecord.type}
                                </code>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0"
                                  onClick={() => copyToClipboard(domain.txtRecord.type, `type-${index}`)}
                                >
                                  {copiedField === `type-${index}` ? (
                                    <Check className="h-3 w-3 text-green-500" />
                                  ) : (
                                    <Copy className="h-3 w-3" />
                                  )}
                                </Button>
                              </div>
                            </div>

                            <div className="grid grid-cols-4 items-center gap-2">
                              <Label className="text-sm font-medium">名稱:</Label>
                              <div className="col-span-2 flex items-center gap-2">
                                <code className="px-2 py-1 bg-muted rounded text-sm font-mono break-all">
                                  {domain.txtRecord.name}
                                </code>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0"
                                  onClick={() => copyToClipboard(domain.txtRecord.name, `name-${index}`)}
                                >
                                  {copiedField === `name-${index}` ? (
                                    <Check className="h-3 w-3 text-green-500" />
                                  ) : (
                                    <Copy className="h-3 w-3" />
                                  )}
                                </Button>
                              </div>
                            </div>

                            <div className="grid grid-cols-4 items-start gap-2">
                              <Label className="text-sm font-medium">內容:</Label>
                              <div className="col-span-2 flex items-start gap-2">
                                <code className="px-2 py-1 bg-muted rounded text-sm font-mono break-all leading-relaxed">
                                  {domain.txtRecord.content}
                                </code>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0 mt-1"
                                  onClick={() => copyToClipboard(domain.txtRecord.content, `content-${index}`)}
                                >
                                  {copiedField === `content-${index}` ? (
                                    <Check className="h-3 w-3 text-green-500" />
                                  ) : (
                                    <Copy className="h-3 w-3" />
                                  )}
                                </Button>
                              </div>
                            </div>
                          </div>
                          <p className="text-xs text-muted-foreground mt-3">
                            請將以上 TXT 記錄添加到您的 DNS 設定中以完成域名驗證
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 子域名設定 */}
            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Globe className="h-5 w-5 text-purple-500" />
                  <div>
                    <h3 className="font-medium">子域名設定</h3>
                    <p className="text-sm text-muted-foreground">管理子域名的WAF防護配置</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    {subdomains.length}個已配置
                  </Badge>
                  <Dialog open={isSubdomainDialogOpen} onOpenChange={setIsSubdomainDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        設定
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>子域名設定</DialogTitle>
                        <DialogDescription>請選擇主域名並輸入子域名前綴</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="main-domain" className="text-right">
                            主域名
                          </Label>
                          <Select value={selectedMainDomain} onValueChange={setSelectedMainDomain}>
                            <SelectTrigger className="col-span-3">
                              <SelectValue placeholder="選擇主域名" />
                            </SelectTrigger>
                            <SelectContent>
                              {mainDomains.map((domain, index) => (
                                <SelectItem key={index} value={domain.name}>
                                  {domain.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="subdomain" className="text-right">
                            子域名
                          </Label>
                          <div className="col-span-3 flex items-center">
                            <Input
                              id="subdomain"
                              placeholder="例如: api、admin、www"
                              value={subdomainInput}
                              onChange={(e) => setSubdomainInput(e.target.value)}
                              className="flex-1"
                            />
                            <span className="ml-2 text-muted-foreground">.{selectedMainDomain || "選擇主域名"}</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="record-type" className="text-right">
                            類型
                          </Label>
                          <Select value={recordType} onValueChange={setRecordType}>
                            <SelectTrigger className="col-span-3">
                              <SelectValue placeholder="選擇類型" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="A">A</SelectItem>
                              <SelectItem value="AAAA">AAAA</SelectItem>
                              <SelectItem value="CNAME">CNAME</SelectItem>
                              <SelectItem value="MX">MX</SelectItem>
                              <SelectItem value="TXT">TXT</SelectItem>
                              <SelectItem value="SRV">SRV</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="ipv4-address" className="text-right">
                            IPv4 位址
                          </Label>
                          <Input
                            id="ipv4-address"
                            placeholder="192.168.1.1"
                            value={ipv4Address}
                            onChange={(e) => setIpv4Address(e.target.value)}
                            className="col-span-3"
                          />
                        </div>

                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label className="text-right">Proxy 狀態</Label>
                          <div className="col-span-3 flex items-center gap-3">
                            <Switch checked={proxyStatus} onCheckedChange={setProxyStatus} />
                            <span className="text-sm text-muted-foreground">
                              {proxyStatus ? "通過Proxy處理" : "僅DNS"}
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label className="text-right">TTL</Label>
                          <div className="col-span-3">
                            <span className="text-sm text-muted-foreground">自動</span>
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button
                          type="submit"
                          onClick={handleSubdomainSubmit}
                          disabled={!subdomainInput.trim() || !selectedMainDomain}
                        >
                          送出
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              {/* 子域名列表 */}
              {subdomains.length > 0 && (
                <div className="ml-8 space-y-2">
                  <div className="grid grid-cols-12 gap-4 p-3 border-b font-medium text-sm text-muted-foreground">
                    <div className="col-span-3">名稱</div>
                    <div className="col-span-2">類型</div>
                    <div className="col-span-2">內容</div>
                    <div className="col-span-2">Proxy狀態</div>
                    <div className="col-span-1">TTL</div>
                    <div className="col-span-2">操作</div>
                  </div>
                  {subdomains.map((domain, index) => (
                    <React.Fragment key={index}>
                      {/* 列表列 */}
                      <div className="grid grid-cols-12 gap-4 items-center p-3 border rounded-lg bg-muted/30">
                        <div className="col-span-3 flex items-center gap-2">
                          <div
                            className={`w-2 h-2 rounded-full ${
                              domain.status === "防護中" ? "bg-green-500" : "bg-yellow-500"
                            }`}
                          />
                          <div>
                            <p className="font-medium text-sm">{domain.name}</p>
                          </div>
                        </div>

                        <div className="col-span-2">
                          <Badge variant="secondary" className="text-xs">
                            {domain.recordType || "A"}
                          </Badge>
                        </div>

                        <div className="col-span-2">
                          <span className="text-sm font-mono">{domain.ipAddress || "192.168.1.1"}</span>
                        </div>

                        <div className="col-span-2">
                          <div className="flex items-center gap-2">
                            <Switch checked={domain.proxy} disabled className="scale-75" />
                            <span className="text-xs">{domain.proxy ? "通過Proxy處理" : "僅DNS"}</span>
                          </div>
                        </div>

                        <div className="col-span-1">
                          <span className="text-sm text-muted-foreground">
                            {domain.ttl === "auto" ? "自動" : domain.ttl || "自動"}
                          </span>
                        </div>

                        <div className="col-span-2 flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => toggleEditForm(domain.name)}
                          >
                            <Settings className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                            onClick={() => handleDeleteDomain(domain.name)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      {/* 編輯表單 */}
                      {expandedEditForms[domain.name] && editingDomain && (
                        <div className="mt-4 p-4 border rounded-lg bg-blue-50 dark:bg-blue-950/30 animate-in slide-in-from-top-2 duration-200">
                          <h4 className="font-medium text-sm mb-4 text-blue-700 dark:text-blue-300">編輯子域名設定</h4>

                          <div className="grid grid-cols-2 gap-4">
                            {/* 名稱欄位 - 新增 */}
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">子域名名稱</Label>
                              <Input
                                value={editingDomain.name}
                                onChange={(e) => setEditingDomain((prev) => ({ ...prev, name: e.target.value }))}
                                placeholder="例如: api、admin、www"
                              />
                            </div>

                            {/* 記錄類型 */}
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">記錄類型</Label>
                              <Select
                                value={editingDomain.recordType}
                                onValueChange={(value) => setEditingDomain((prev) => ({ ...prev, recordType: value }))}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="A">A</SelectItem>
                                  <SelectItem value="AAAA">AAAA</SelectItem>
                                  <SelectItem value="CNAME">CNAME</SelectItem>
                                  <SelectItem value="MX">MX</SelectItem>
                                  <SelectItem value="TXT">TXT</SelectItem>
                                  <SelectItem value="SRV">SRV</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>

                            {/* IP 位址 */}
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">IPv4 位址</Label>
                              <Input
                                value={editingDomain.ipAddress}
                                onChange={(e) => setEditingDomain((prev) => ({ ...prev, ipAddress: e.target.value }))}
                                placeholder="192.168.1.1"
                              />
                            </div>

                            {/* Proxy 狀態 - 改為開關 */}
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">Proxy 狀態</Label>
                              <div className="flex items-center gap-3">
                                <Switch
                                  checked={editingDomain.proxy}
                                  onCheckedChange={(checked) =>
                                    setEditingDomain((prev) => ({ ...prev, proxy: checked }))
                                  }
                                />
                                <span className="text-sm text-muted-foreground">
                                  {editingDomain.proxy ? "通過Proxy處理" : "僅DNS"}
                                </span>
                              </div>
                            </div>

                            {/* TTL - 移到 Proxy 狀態旁邊 */}
                            <div className="space-y-2">
                              <Label className="text-sm font-medium">TTL</Label>
                              <Select
                                value={editingDomain.ttl}
                                onValueChange={(value) => setEditingDomain((prev) => ({ ...prev, ttl: value }))}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="auto">自動</SelectItem>
                                  <SelectItem value="300">5分鐘</SelectItem>
                                  <SelectItem value="1800">30分鐘</SelectItem>
                                  <SelectItem value="3600">1小時</SelectItem>
                                  <SelectItem value="86400">1天</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>

                          {/* 操作按鈕 */}
                          <div className="flex justify-end gap-2 mt-4">
                            <Button variant="outline" size="sm" onClick={() => toggleEditForm(domain.name)}>
                              取消
                            </Button>
                            <Button size="sm" onClick={() => handleEditSubmit(domain.name)}>
                              儲存變更
                            </Button>
                          </div>
                        </div>
                      )}
                    </React.Fragment>
                  ))}
                </div>
              )}
            </div>

            {/* WAF 政策 - 移除中等安全標示 */}
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-red-500" />
                <div>
                  <h3 className="font-medium">WAF 政策</h3>
                  <p className="text-sm text-muted-foreground">配置安全規則和防護政策</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Dialog open={isWafPolicyDialogOpen} onOpenChange={setIsWafPolicyDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      設定
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[800px] max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <Shield className="h-5 w-5 text-red-500" />
                        WAF 安全政策設定
                      </DialogTitle>
                      <DialogDescription>配置黑名單、白名單和國別阻擋設定來加強您的網站安全防護</DialogDescription>
                    </DialogHeader>

                    <Tabs defaultValue="blacklist" className="w-full">
                      <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="blacklist" className="flex items-center gap-2">
                          <Ban className="h-4 w-4" />
                          黑名單
                        </TabsTrigger>
                        <TabsTrigger value="whitelist" className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4" />
                          白名單
                        </TabsTrigger>
                        <TabsTrigger value="countries" className="flex items-center gap-2">
                          <Flag className="h-4 w-4" />
                          國別阻擋
                        </TabsTrigger>
                      </TabsList>

                      {/* 黑名單設定 */}
                      <TabsContent value="blacklist" className="space-y-4">
                        <div className="space-y-4">
                          <div className="flex items-center gap-2">
                            <Input
                              placeholder="輸入 IP 地址或域名 (例如: 192.168.1.1 或 malicious-site.com)"
                              value={blacklistInput}
                              onChange={(e) => setBlacklistInput(e.target.value)}
                              className="flex-1"
                            />
                            <Button onClick={addToBlacklist} disabled={!blacklistInput.trim()}>
                              <Plus className="h-4 w-4 mr-2" />
                              新增
                            </Button>
                          </div>

                          {/* 子域名選擇區域 */}
                          <div className="space-y-3">
                            <h4 className="font-medium text-sm">選擇要加入黑名單的子域名</h4>
                            <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto p-3 border rounded-lg bg-muted/30">
                              {subdomains.map((domain, index) => (
                                <div key={index} className="flex items-center space-x-2">
                                  <input
                                    type="checkbox"
                                    id={`subdomain-${index}`}
                                    checked={selectedSubdomains.includes(domain.name)}
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setSelectedSubdomains((prev) => [...prev, domain.name])
                                      } else {
                                        setSelectedSubdomains((prev) => prev.filter((name) => name !== domain.name))
                                      }
                                    }}
                                    className="rounded border-gray-300"
                                  />
                                  <label htmlFor={`subdomain-${index}`} className="text-sm cursor-pointer">
                                    {domain.name}
                                  </label>
                                </div>
                              ))}
                            </div>
                            {selectedSubdomains.length > 0 && (
                              <Button
                                onClick={() => {
                                  selectedSubdomains.forEach((subdomain) => {
                                    const newItem = {
                                      id: Date.now() + Math.random(),
                                      value: subdomain,
                                      type: "子域名",
                                    }
                                    setBlacklist((prev) => [...prev, newItem])
                                  })
                                  setSelectedSubdomains([])
                                }}
                                className="w-full"
                              >
                                將選中的子域名加入黑名單 ({selectedSubdomains.length})
                              </Button>
                            )}
                          </div>

                          <div className="space-y-2">
                            <h4 className="font-medium text-sm">目前黑名單 ({blacklist.length} 項)</h4>
                            <div className="max-h-48 overflow-y-auto space-y-2">
                              {blacklist.map((item) => (
                                <div
                                  key={item.id}
                                  className="flex items-center justify-between p-3 border rounded-lg bg-red-50 dark:bg-red-950/30"
                                >
                                  <div className="flex items-center gap-3">
                                    <Ban className="h-4 w-4 text-red-500" />
                                    <div>
                                      <p className="font-medium text-sm">{item.value}</p>
                                      <p className="text-xs text-muted-foreground">{item.type}</p>
                                    </div>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => removeFromBlacklist(item.id)}
                                    className="text-red-500 hover:text-red-700"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </TabsContent>

                      {/* 白名單設定 */}
                      <TabsContent value="whitelist" className="space-y-4">
                        <div className="space-y-4">
                          <div className="flex items-center gap-2">
                            <Input
                              placeholder="輸入 IP 地址、IP段或域名 (例如: 203.0.113.0/24 或 trusted-site.com)"
                              value={whitelistInput}
                              onChange={(e) => setWhitelistInput(e.target.value)}
                              className="flex-1"
                            />
                            <Button onClick={addToWhitelist} disabled={!whitelistInput.trim()}>
                              <Plus className="h-4 w-4 mr-2" />
                              新增
                            </Button>
                          </div>

                          {/* 子域名選擇區域 - 新增 */}
                          <div className="space-y-3">
                            <h4 className="font-medium text-sm">選擇要加入白名單的子域名</h4>
                            <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto p-3 border rounded-lg bg-muted/30">
                              {subdomains.map((domain, index) => (
                                <div key={index} className="flex items-center space-x-2">
                                  <input
                                    type="checkbox"
                                    id={`whitelist-subdomain-${index}`}
                                    checked={selectedSubdomains.includes(domain.name)}
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setSelectedSubdomains((prev) => [...prev, domain.name])
                                      } else {
                                        setSelectedSubdomains((prev) => prev.filter((name) => name !== domain.name))
                                      }
                                    }}
                                    className="rounded border-gray-300"
                                  />
                                  <label htmlFor={`whitelist-subdomain-${index}`} className="text-sm cursor-pointer">
                                    {domain.name}
                                  </label>
                                </div>
                              ))}
                            </div>
                            {selectedSubdomains.length > 0 && (
                              <Button
                                onClick={() => {
                                  selectedSubdomains.forEach((subdomain) => {
                                    const newItem = {
                                      id: Date.now() + Math.random(),
                                      value: subdomain,
                                      type: "子域名",
                                    }
                                    setWhitelist((prev) => [...prev, newItem])
                                  })
                                  setSelectedSubdomains([])
                                }}
                                className="w-full"
                                variant="outline"
                              >
                                將選中的子域名加入白名單 ({selectedSubdomains.length})
                              </Button>
                            )}
                          </div>

                          <div className="space-y-2">
                            <h4 className="font-medium text-sm">目前白名單 ({whitelist.length} 項)</h4>
                            <div className="max-h-48 overflow-y-auto space-y-2">
                              {whitelist.map((item) => (
                                <div
                                  key={item.id}
                                  className="flex items-center justify-between p-3 border rounded-lg bg-green-50 dark:bg-green-950/30"
                                >
                                  <div className="flex items-center gap-3">
                                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                                    <div>
                                      <p className="font-medium text-sm">{item.value}</p>
                                      <p className="text-xs text-muted-foreground">{item.type}</p>
                                    </div>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => removeFromWhitelist(item.id)}
                                    className="text-red-500 hover:text-red-700"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </TabsContent>

                      {/* 國別阻擋設定 */}
                      <TabsContent value="countries" className="space-y-4">
                        <div className="space-y-4">
                          <div className="space-y-3">
                            <h4 className="font-medium text-sm">訪問控制模式</h4>
                            <RadioGroup
                              value={countryAccessMode}
                              onValueChange={setCountryAccessMode}
                              className="flex gap-6"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="block" id="block" />
                                <Label htmlFor="block">阻擋</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="allow" id="allow" />
                                <Label htmlFor="allow">放行</Label>
                              </div>
                            </RadioGroup>
                          </div>

                          <div className="flex items-center gap-2">
                            <Select onValueChange={addBlockedCountry}>
                              <SelectTrigger className="flex-1">
                                <SelectValue
                                  placeholder={countryAccessMode === "block" ? "選擇要阻擋的國家" : "選擇要放行的國家"}
                                />
                              </SelectTrigger>
                              <SelectContent>
                                {countries
                                  .filter(
                                    (country) => !blockedCountries.find((blocked) => blocked.code === country.code),
                                  )
                                  .map((country) => (
                                    <SelectItem key={country.code} value={country.code}>
                                      {country.name} ({country.code})
                                    </SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                          </div>

                          {/* 子域名選擇區域 */}
                          <div className="space-y-3">
                            <h4 className="font-medium text-sm">選擇要應用此規則的子域名</h4>
                            <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto p-3 border rounded-lg bg-muted/30">
                              {subdomains.map((domain, index) => (
                                <div key={index} className="flex items-center space-x-2">
                                  <input
                                    type="checkbox"
                                    id={`country-subdomain-${index}`}
                                    checked={selectedSubdomains.includes(domain.name)}
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setSelectedSubdomains((prev) => [...prev, domain.name])
                                      } else {
                                        setSelectedSubdomains((prev) => prev.filter((name) => name !== domain.name))
                                      }
                                    }}
                                    className="rounded border-gray-300"
                                  />
                                  <label htmlFor={`country-subdomain-${index}`} className="text-sm cursor-pointer">
                                    {domain.name}
                                  </label>
                                </div>
                              ))}
                            </div>
                            {selectedSubdomains.length > 0 && (
                              <Button
                                onClick={() => {
                                  selectedSubdomains.forEach((subdomain) => {
                                    const newItem = {
                                      code: "SUBDOMAIN",
                                      name: subdomain,
                                      type: "子域名",
                                    }
                                    setBlockedCountries((prev) => [...prev, newItem])
                                  })
                                  setSelectedSubdomains([])
                                }}
                                className="w-full"
                                variant="outline"
                              >
                                將選中的子域名加入{countryAccessMode === "block" ? "阻擋" : "放行"}清單 (
                                {selectedSubdomains.length})
                              </Button>
                            )}
                          </div>

                          <div className="space-y-2">
                            <h4 className="font-medium text-sm">
                              {countryAccessMode === "block" ? "目前拒絕訪問的國家" : "目前允許訪問的國家"} (
                              {blockedCountries.length} 個)
                            </h4>
                            <div className="max-h-48 overflow-y-auto space-y-2">
                              {blockedCountries.map((country) => (
                                <div
                                  key={country.code}
                                  className="flex items-center justify-between p-3 border rounded-lg bg-orange-50 dark:bg-orange-950/30"
                                >
                                  <div className="flex items-center gap-3">
                                    <Flag className="h-4 w-4 text-orange-500" />
                                    <div>
                                      <p className="font-medium text-sm">{country.name}</p>
                                      <p className="text-xs text-muted-foreground">
                                        {country.type ? `${country.type} • ` : `國家代碼: ${country.code}`}
                                      </p>
                                    </div>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => removeBlockedCountry(country.code)}
                                    className="text-red-500 hover:text-red-700"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                    </Tabs>

                    <DialogFooter>
                      <Button onClick={() => setIsWafPolicyDialogOpen(false)}>完成設定</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Analytics Dashboard - Complete WAFAnalytics */}
        <div className="mb-16">
          <h2 className="text-3xl font-semibold text-center mb-12 text-foreground">
            防護<span style={{ color: "#0D99FF" }}>分析</span>
          </h2>
          <WAFAnalytics />
        </div>

        {/* 快速操作 */}
        <Card>
          <CardHeader>
            <CardTitle>快速操作</CardTitle>
            <CardDescription>常用的WAF管理操作</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Link href="/services/hiwaf/manage/security-logs">
                <Button variant="outline" className="h-auto p-4 justify-start bg-transparent w-full">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-5 w-5 text-orange-500" />
                    <div className="text-left">
                      <p className="font-medium">查看安全日誌</p>
                      <p className="text-sm text-muted-foreground">檢視詳細的安全事件記錄</p>
                    </div>
                  </div>
                </Button>
              </Link>

              <Button variant="outline" className="h-auto p-4 justify-start bg-transparent">
                <div className="flex items-center gap-3">
                  <Settings className="h-5 w-5 text-blue-500" />
                  <div className="text-left">
                    <p className="font-medium">規則配置</p>
                    <p className="text-sm text-muted-foreground">自定義WAF防護規則</p>
                  </div>
                </div>
              </Button>

              <Button variant="outline" className="h-auto p-4 justify-start bg-transparent">
                <div className="flex items-center gap-3">
                  <Globe className="h-5 w-5 text-green-500" />
                  <div className="text-left">
                    <p className="font-medium">添加域名</p>
                    <p className="text-sm text-muted-foreground">新增需要保護的域名</p>
                  </div>
                </div>
              </Button>

              <Button variant="outline" className="h-auto p-4 justify-start bg-transparent">
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-purple-500" />
                  <div className="text-left">
                    <p className="font-medium">安全報告</p>
                    <p className="text-sm text-muted-foreground">生成詳細的安全分析報告</p>
                  </div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function WAFAnalytics() {
  // 模擬數據
  const attackBlockData = [
    { name: "1月", SQL注入: 145, XSS攻擊: 89, CSRF: 56, 其他: 34 },
    { name: "2月", SQL注入: 132, XSS攻擊: 76, CSRF: 48, 其他: 29 },
    { name: "3月", SQL注入: 168, XSS攻擊: 95, CSRF: 62, 其他: 41 },
    { name: "4月", SQL注入: 124, XSS攻擊: 71, CSRF: 45, 其他: 28 },
    { name: "5月", SQL注入: 108, XSS攻擊: 63, CSRF: 39, 其他: 24 },
    { name: "6月", SQL注入: 95, XSS攻擊: 55, CSRF: 33, 其他: 19 },
  ]

  const performanceData = [
    { name: "1月", 響應時間: 12, 阻擋率: 96.8 },
    { name: "2月", 響應時間: 11, 阻擋率: 97.2 },
    { name: "3月", 響應時間: 10, 阻擋率: 97.8 },
    { name: "4月", 響應時間: 9, 阻擋率: 98.1 },
    { name: "5月", 響應時間: 8, 阻擋率: 98.5 },
    { name: "6月", 響應時間: 7, 阻擋率: 98.9 },
  ]

  const threatTypeData = [
    { name: "SQL注入", value: 40, color: "#ef4444" },
    { name: "XSS攻擊", value: 30, color: "#f97316" },
    { name: "CSRF", value: 20, color: "#eab308" },
    { name: "其他攻擊", value: 10, color: "#a3a3a3" },
  ]

  const trafficData = [
    { name: "1月", 正常流量: 8500, 惡意流量: 324 },
    { name: "2月", 正常流量: 9200, 惡意流量: 285 },
    { name: "3月", 正常流量: 10500, 惡意流量: 366 },
    { name: "4月", 正常流量: 11800, 惡意流量: 268 },
    { name: "5月", 正常流量: 12500, 惡意流量: 234 },
    { name: "6月", 正常流量: 13200, 惡意流量: 202 },
  ]

  return (
    <div className="space-y-8">
      {/* 統計卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard
          title="攻擊阻擋率"
          value="98.9%"
          description="本月攻擊阻擋成功率"
          trend="+0.4%"
          trendType="positive"
          icon={<Shield className="h-8 w-8" style={{ color: "#0D99FF" }} />}
        />
        <StatCard
          title="響應時間"
          value="7ms"
          description="平均檢測響應時間"
          trend="-12.5%"
          trendType="positive"
          icon={<TrendingUp className="h-8 w-8" style={{ color: "#0D99FF" }} />}
        />
        <StatCard
          title="攻擊次數"
          value="202"
          description="本月檢測攻擊次數"
          trend="-13.7%"
          trendType="positive"
          icon={<Eye className="h-8 w-8" style={{ color: "#0D99FF" }} />}
        />
        <StatCard
          title="保護網站"
          value="13,200"
          description="本月保護正常訪問"
          trend="+5.6%"
          trendType="positive"
          icon={<Server className="h-8 w-8" style={{ color: "#0D99FF" }} />}
        />
      </div>

      {/* 圖表區域 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-lg bg-card border-border">
          <CardHeader>
            <CardTitle className="text-xl text-foreground">攻擊類型阻擋統計</CardTitle>
            <CardDescription className="text-muted-foreground">過去6個月的攻擊類型和阻擋數量</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={attackBlockData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      borderColor: "hsl(var(--border))",
                      color: "hsl(var(--foreground))",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="SQL注入" stackId="a" fill="#ef4444" />
                  <Bar dataKey="XSS攻擊" stackId="a" fill="#f97316" />
                  <Bar dataKey="CSRF" stackId="a" fill="#eab308" />
                  <Bar dataKey="其他" stackId="a" fill="#a3a3a3" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-card border-border">
          <CardHeader>
            <CardTitle className="text-xl text-foreground">性能優化趨勢</CardTitle>
            <CardDescription className="text-muted-foreground">響應時間和阻擋率改善情況</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsLineChart data={performanceData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      borderColor: "hsl(var(--border))",
                      color: "hsl(var(--foreground))",
                    }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="響應時間" stroke="#ef4444" strokeWidth={2} />
                  <Line type="monotone" dataKey="阻擋率" stroke="#22b866" strokeWidth={2} />
                </RechartsLineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1 shadow-lg bg-card border-border">
          <CardHeader>
            <CardTitle className="text-xl text-foreground">威脅類型分佈</CardTitle>
            <CardDescription className="text-muted-foreground">檢測到的攻擊類型比例</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={threatTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {threatTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      borderColor: "hsl(var(--border))",
                      color: "hsl(var(--foreground))",
                    }}
                  />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-lg bg-card border-border">
          <CardHeader>
            <CardTitle className="text-xl text-foreground">流量處理統計</CardTitle>
            <CardDescription className="text-muted-foreground">正常流量與惡意流量處理情況</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trafficData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      borderColor: "hsl(var(--border))",
                      color: "hsl(var(--foreground))",
                    }}
                  />
                  <Legend />
                  <Area type="monotone" dataKey="正常流量" stackId="1" stroke="#22b866" fill="#22b866" />
                  <Area type="monotone" dataKey="惡意流量" stackId="1" stroke="#ef4444" fill="#ef4444" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 全球攻擊來源地圖 - 新增的地圖區塊 */}
      <Card className="shadow-lg bg-card border-border">
        <CardHeader>
          <CardTitle className="text-xl text-foreground flex items-center gap-2">
            <Globe className="h-5 w-5" style={{ color: "#0D99FF" }} />
            全球攻擊來源地圖
          </CardTitle>
          <CardDescription className="text-muted-foreground">過去30天全球攻擊來源分佈統計</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <div className="h-96 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 rounded-lg border-2 border-dashed border-blue-200 dark:border-blue-800 flex items-center justify-center">
              <div className="text-center">
                <Globe className="h-20 w-20 mx-auto mb-4 text-blue-500" />
                <p className="text-2xl font-medium text-blue-700 dark:text-blue-300">世界地圖視覺化</p>
                <p className="text-lg text-blue-600 dark:text-blue-400 mt-2">攻擊來源熱點分佈圖</p>
                <p className="text-sm text-blue-500 dark:text-blue-500 mt-4">即時監控全球網路威脅</p>
              </div>
            </div>
            {/* 模擬攻擊點 - 更多動畫效果 */}
            <div className="absolute top-8 left-12 w-4 h-4 bg-red-500 rounded-full animate-pulse shadow-lg"></div>
            <div className="absolute top-16 right-16 w-3 h-3 bg-orange-500 rounded-full animate-pulse shadow-lg"></div>
            <div className="absolute bottom-20 left-20 w-5 h-5 bg-red-600 rounded-full animate-pulse shadow-lg"></div>
            <div className="absolute bottom-12 right-12 w-3 h-3 bg-yellow-500 rounded-full animate-pulse shadow-lg"></div>
            <div className="absolute top-1/2 left-1/3 w-4 h-4 bg-red-400 rounded-full animate-pulse shadow-lg"></div>
            <div className="absolute top-1/3 right-1/4 w-3 h-3 bg-orange-400 rounded-full animate-pulse shadow-lg"></div>
            <div className="absolute bottom-1/3 left-1/2 w-4 h-4 bg-red-500 rounded-full animate-pulse shadow-lg"></div>
            <div className="absolute top-2/3 right-1/3 w-2 h-2 bg-yellow-400 rounded-full animate-pulse shadow-lg"></div>

            {/* 攻擊波紋效果 */}
            <div className="absolute top-8 left-12 w-8 h-8 border-2 border-red-300 rounded-full animate-ping"></div>
            <div className="absolute bottom-20 left-20 w-10 h-10 border-2 border-red-400 rounded-full animate-ping"></div>
            <div className="absolute top-1/2 left-1/3 w-8 h-8 border-2 border-red-300 rounded-full animate-ping"></div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function StatCard({ title, value, description, trend, trendType, icon }) {
  return (
    <Card className="shadow-lg bg-card border-border">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-3xl font-bold text-foreground mt-2">{value}</p>
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
          </div>
          <div className="bg-muted p-3 rounded-full">{icon}</div>
        </div>
        <div
          className={`mt-4 flex items-center text-sm ${trendType === "positive" ? "text-green-500" : "text-red-500"}`}
        >
          {trendType === "positive" ? (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
              <path
                fillRule="evenodd"
                d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 9.414 14.586 13H12z"
                clipRule="evenodd"
              />
            </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
              <path
                fillRule="evenodd"
                d="M12 13a1 1 0 100 2h5a1 1 0 001-1V9a1 1 0 10-2 0v3.586l-4.293-4.293a1 1 0 00-1.414 0L8 9.586 3.707 5.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0L11 9.414 14.586 13H12z"
                clipRule="evenodd"
              />
            </svg>
          )}
          {trend}
        </div>
      </CardContent>
    </Card>
  )
}
