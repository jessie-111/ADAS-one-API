"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Shield,
  Search,
  Download,
  Eye,
  AlertTriangle,
  Clock,
  Globe,
  ChevronRight,
  TrendingUp,
  Activity,
  Zap,
  Target,
  Network,
  FileText,
  BarChart3,
  Server,
  Users,
  MousePointer,
  Calendar,
  MapPin,
  Building,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart as RechartsLineChart,
  Line,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  BarChart as RechartsBarChart,
  Bar,
  AreaChart as RechartsAreaChart,
  Area,
} from "recharts"

export default function SecurityLogsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedSeverity, setSelectedSeverity] = useState("all")
  const [selectedTimeRange, setSelectedTimeRange] = useState("24h")
  const [selectedLogType, setSelectedLogType] = useState("all")
  const [selectedLogDetail, setSelectedLogDetail] = useState(null)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)
  const [trafficTimeRange, setTrafficTimeRange] = useState("7d")

  // 模擬安全日誌數據
  const securityLogs = [
    {
      id: "LOG-001",
      timestamp: "2024-01-22 14:30:25",
      severity: "高危",
      type: "SQL注入攻擊",
      sourceIP: "192.168.1.100",
      targetURL: "/api/users",
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      action: "已阻擋",
      ruleId: "WAF-001",
      country: "中國",
      details: {
        payload: "' OR 1=1 --",
        headers: {
          "Content-Type": "application/json",
          "X-Forwarded-For": "192.168.1.100",
        },
        response: "403 Forbidden",
      },
    },
    {
      id: "LOG-002",
      timestamp: "2024-01-22 14:28:15",
      severity: "中危",
      type: "XSS攻擊",
      sourceIP: "203.0.113.45",
      targetURL: "/search",
      userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
      action: "已阻擋",
      ruleId: "WAF-002",
      country: "美國",
      details: {
        payload: "<script>alert('xss')</script>",
        headers: {
          "Content-Type": "text/html",
          Referer: "https://example.com",
        },
        response: "403 Forbidden",
      },
    },
    {
      id: "LOG-003",
      timestamp: "2024-01-22 14:25:10",
      severity: "低危",
      type: "異常請求頻率",
      sourceIP: "198.51.100.23",
      targetURL: "/api/data",
      userAgent: "curl/7.68.0",
      action: "已限制",
      ruleId: "RATE-001",
      country: "日本",
      details: {
        requestCount: 150,
        timeWindow: "1分鐘",
        threshold: 100,
        response: "429 Too Many Requests",
      },
    },
    {
      id: "LOG-004",
      timestamp: "2024-01-22 14:20:05",
      severity: "高危",
      type: "目錄遍歷攻擊",
      sourceIP: "172.16.0.50",
      targetURL: "/files/../../../etc/passwd",
      userAgent: "Python-requests/2.28.1",
      action: "已阻擋",
      ruleId: "WAF-003",
      country: "俄羅斯",
      details: {
        payload: "../../../etc/passwd",
        headers: {
          "User-Agent": "Python-requests/2.28.1",
        },
        response: "403 Forbidden",
      },
    },
    {
      id: "LOG-005",
      timestamp: "2024-01-22 14:15:30",
      severity: "中危",
      type: "CSRF攻擊",
      sourceIP: "10.0.0.25",
      targetURL: "/api/transfer",
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      action: "已阻擋",
      ruleId: "WAF-004",
      country: "德國",
      details: {
        missingToken: true,
        referer: "http://malicious-site.com",
        response: "403 Forbidden",
      },
    },
  ]

  // 日誌統計數據
  const logStats = {
    total: 1247,
    blocked: 1180,
    allowed: 67,
    highSeverity: 234,
    mediumSeverity: 456,
    lowSeverity: 557,
  }

  // 攻擊類型分佈數據
  const attackTypeData = [
    { name: "SQL注入", value: 45, color: "#ef4444" },
    { name: "XSS攻擊", value: 32, color: "#f97316" },
    { name: "CSRF", value: 18, color: "#eab308" },
    { name: "目錄遍歷", value: 15, color: "#8b5cf6" },
    { name: "其他", value: 10, color: "#6b7280" },
  ]

  // 時間趨勢數據
  const timeSeriesData = [
    { time: "00:00", attacks: 12, blocked: 11 },
    { time: "04:00", attacks: 8, blocked: 8 },
    { time: "08:00", attacks: 25, blocked: 23 },
    { time: "12:00", attacks: 45, blocked: 42 },
    { time: "16:00", attacks: 38, blocked: 35 },
    { time: "20:00", attacks: 28, blocked: 26 },
  ]

  // 地理分佈數據
  const geoData = [
    { country: "中國", attacks: 156, percentage: 35 },
    { country: "俄羅斯", attacks: 89, percentage: 20 },
    { country: "美國", attacks: 67, percentage: 15 },
    { country: "德國", attacks: 45, percentage: 10 },
    { country: "其他", attacks: 89, percentage: 20 },
  ]

  // HTTP流量分析數據
  const trafficStats = {
    totalRequests: 2847592,
    uniqueVisitors: 45678,
    bandwidth: "1.2TB",
    avgResponseTime: "245ms",
    successRate: 98.5,
    errorRate: 1.5,
  }

  // 整體HTTP流量趨勢數據
  const httpTrafficData = [
    { date: "01-15", requests: 85000, bandwidth: 120, visitors: 3200 },
    { date: "01-16", requests: 92000, bandwidth: 135, visitors: 3450 },
    { date: "01-17", requests: 78000, bandwidth: 110, visitors: 2980 },
    { date: "01-18", requests: 105000, bandwidth: 155, visitors: 3890 },
    { date: "01-19", requests: 98000, bandwidth: 145, visitors: 3650 },
    { date: "01-20", requests: 112000, bandwidth: 168, visitors: 4120 },
    { date: "01-21", requests: 125000, bandwidth: 185, visitors: 4580 },
    { date: "01-22", requests: 118000, bandwidth: 172, visitors: 4250 },
  ]

  // 子網域流量數據
  const subdomainData = [
    { subdomain: "www.example.com", requests: 1250000, percentage: 43.9, bandwidth: "520GB" },
    { subdomain: "api.example.com", requests: 890000, percentage: 31.3, bandwidth: "380GB" },
    { subdomain: "cdn.example.com", requests: 456000, percentage: 16.0, bandwidth: "210GB" },
    { subdomain: "admin.example.com", requests: 125000, percentage: 4.4, bandwidth: "65GB" },
    { subdomain: "blog.example.com", requests: 89000, percentage: 3.1, bandwidth: "45GB" },
    { subdomain: "其他", requests: 37592, percentage: 1.3, bandwidth: "20GB" },
  ]

  // HTTP狀態碼數據
  const httpStatusData = [
    { status: "200", name: "成功", count: 2654321, percentage: 93.2, color: "#22c55e" },
    { status: "404", name: "未找到", count: 125678, percentage: 4.4, color: "#f59e0b" },
    { status: "403", name: "禁止訪問", count: 34567, percentage: 1.2, color: "#ef4444" },
    { status: "500", name: "服務器錯誤", count: 18945, percentage: 0.7, color: "#dc2626" },
    { status: "302", name: "重定向", count: 14081, percentage: 0.5, color: "#3b82f6" },
  ]

  // 地區請求量數據
  const regionRequestData = [
    { region: "亞洲", country: "中國", requests: 1245678, percentage: 43.7, flag: "🇨🇳" },
    { region: "北美", country: "美國", requests: 567890, percentage: 19.9, flag: "🇺🇸" },
    { region: "歐洲", country: "德國", requests: 234567, percentage: 8.2, flag: "🇩🇪" },
    { region: "亞洲", country: "日本", requests: 189456, percentage: 6.7, flag: "🇯🇵" },
    { region: "歐洲", country: "英國", requests: 156789, percentage: 5.5, flag: "🇬🇧" },
    { region: "亞洲", country: "韓國", requests: 123456, percentage: 4.3, flag: "🇰🇷" },
    { region: "其他", country: "其他", requests: 329756, percentage: 11.7, flag: "🌍" },
  ]

  // ASN數據
  const asnData = [
    { asn: "AS4134", name: "中國電信", requests: 456789, percentage: 16.0, country: "中國" },
    { asn: "AS4837", name: "中國聯通", requests: 345678, percentage: 12.1, country: "中國" },
    { asn: "AS15169", name: "Google LLC", requests: 234567, percentage: 8.2, country: "美國" },
    { asn: "AS16509", name: "Amazon.com", requests: 189456, percentage: 6.7, country: "美國" },
    { asn: "AS13335", name: "Cloudflare", requests: 156789, percentage: 5.5, country: "美國" },
    { asn: "AS3462", name: "中華電信", requests: 123456, percentage: 4.3, country: "台灣" },
    { asn: "其他", name: "其他ASN", requests: 1340857, percentage: 47.2, country: "全球" },
  ]

  // 來源IP數據
  const sourceIPData = [
    { ip: "203.0.113.45", requests: 45678, country: "美國", asn: "AS15169", city: "Mountain View" },
    { ip: "198.51.100.23", requests: 34567, country: "德國", asn: "AS3320", city: "Frankfurt" },
    { ip: "192.0.2.100", requests: 28945, country: "日本", asn: "AS2516", city: "Tokyo" },
    { ip: "172.16.0.50", requests: 23456, country: "英國", asn: "AS2856", city: "London" },
    { ip: "10.0.0.25", requests: 19876, country: "加拿大", asn: "AS855", city: "Toronto" },
    { ip: "192.168.1.100", requests: 18765, country: "澳洲", asn: "AS1221", city: "Sydney" },
    { ip: "203.0.113.78", requests: 16543, country: "新加坡", asn: "AS7473", city: "Singapore" },
    { ip: "198.51.100.89", requests: 15432, country: "法國", asn: "AS3215", city: "Paris" },
  ]

  const getSeverityColor = (severity) => {
    switch (severity) {
      case "高危":
        return "text-red-600 bg-red-50 border-red-200"
      case "中危":
        return "text-orange-600 bg-orange-50 border-orange-200"
      case "低危":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  const getActionColor = (action) => {
    switch (action) {
      case "已阻擋":
        return "text-red-600 bg-red-50 border-red-200"
      case "已限制":
        return "text-orange-600 bg-orange-50 border-orange-200"
      case "已允許":
        return "text-green-600 bg-green-50 border-green-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  const filteredLogs = securityLogs.filter((log) => {
    const matchesSearch =
      searchQuery === "" ||
      log.sourceIP.includes(searchQuery) ||
      log.type.includes(searchQuery) ||
      log.targetURL.includes(searchQuery)

    const matchesSeverity = selectedSeverity === "all" || log.severity === selectedSeverity
    const matchesType = selectedLogType === "all" || log.type.includes(selectedLogType)

    return matchesSearch && matchesSeverity && matchesType
  })

  const handleViewDetails = (log) => {
    setSelectedLogDetail(log)
    setIsDetailDialogOpen(true)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
          <Link href="/services" className="hover:text-primary">
            服務總覽
          </Link>
          <ChevronRight className="h-4 w-4" />
          <Link href="/services/hiwaf" className="hover:text-primary">
            WAF防禦
          </Link>
          <ChevronRight className="h-4 w-4" />
          <Link href="/services/hiwaf/manage" className="hover:text-primary">
            管理服務
          </Link>
          <ChevronRight className="h-4 w-4" />
          <span>安全日誌</span>
        </div>
        <h1 className="text-3xl font-semibold tracking-tighter">
          安全<span style={{ color: "#0D99FF" }}>日誌</span>
        </h1>
        <p className="mt-2 text-muted-foreground">查看和分析WAF安全事件日誌，監控網站安全狀況</p>
      </div>

      {/* 統計概覽 */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-8">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">總事件</p>
                <p className="text-2xl font-bold">{logStats.total}</p>
              </div>
              <Activity className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">已阻擋</p>
                <p className="text-2xl font-bold text-red-600">{logStats.blocked}</p>
              </div>
              <Shield className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">已允許</p>
                <p className="text-2xl font-bold text-green-600">{logStats.allowed}</p>
              </div>
              <Eye className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">高危</p>
                <p className="text-2xl font-bold text-red-600">{logStats.highSeverity}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">中危</p>
                <p className="text-2xl font-bold text-orange-600">{logStats.mediumSeverity}</p>
              </div>
              <Zap className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">低危</p>
                <p className="text-2xl font-bold text-yellow-600">{logStats.lowSeverity}</p>
              </div>
              <Target className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 主要內容區域 */}
      <Tabs defaultValue="logs" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="logs" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            日誌查看
          </TabsTrigger>
          <TabsTrigger value="analysis" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            日誌分析
          </TabsTrigger>
          <TabsTrigger value="correlation" className="flex items-center gap-2">
            <Network className="h-4 w-4" />
            關聯分析
          </TabsTrigger>
          <TabsTrigger value="traffic-analysis" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            流量分析
          </TabsTrigger>
        </TabsList>

        {/* 日誌查看 */}
        <TabsContent value="logs" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" style={{ color: "#0D99FF" }} />
                日誌搜索與篩選
              </CardTitle>
              <CardDescription>搜索和篩選安全事件日誌</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>搜索關鍵字</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="IP地址、URL或攻擊類型"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>嚴重程度</Label>
                  <Select value={selectedSeverity} onValueChange={setSelectedSeverity}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部</SelectItem>
                      <SelectItem value="高危">高危</SelectItem>
                      <SelectItem value="中危">中危</SelectItem>
                      <SelectItem value="低危">低危</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>時間範圍</Label>
                  <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1h">過去1小時</SelectItem>
                      <SelectItem value="24h">過去24小時</SelectItem>
                      <SelectItem value="7d">過去7天</SelectItem>
                      <SelectItem value="30d">過去30天</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>攻擊類型</Label>
                  <Select value={selectedLogType} onValueChange={setSelectedLogType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部</SelectItem>
                      <SelectItem value="SQL注入">SQL注入</SelectItem>
                      <SelectItem value="XSS">XSS攻擊</SelectItem>
                      <SelectItem value="CSRF">CSRF攻擊</SelectItem>
                      <SelectItem value="目錄遍歷">目錄遍歷</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  顯示 {filteredLogs.length} 條記錄，共 {securityLogs.length} 條
                </p>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  導出日誌
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>安全事件日誌</CardTitle>
              <CardDescription>實時安全事件記錄</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>時間</TableHead>
                    <TableHead>嚴重程度</TableHead>
                    <TableHead>攻擊類型</TableHead>
                    <TableHead>來源IP</TableHead>
                    <TableHead>目標URL</TableHead>
                    <TableHead>處理動作</TableHead>
                    <TableHead>國家</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="font-mono text-sm">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          {log.timestamp}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={getSeverityColor(log.severity)}>
                          {log.severity}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="font-medium">{log.type}</span>
                      </TableCell>
                      <TableCell className="font-mono">{log.sourceIP}</TableCell>
                      <TableCell className="font-mono text-sm max-w-xs truncate">{log.targetURL}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={getActionColor(log.action)}>
                          {log.action}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Globe className="h-4 w-4 text-muted-foreground" />
                          {log.country}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm" onClick={() => handleViewDetails(log)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 日誌分析 */}
        <TabsContent value="analysis" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>攻擊類型分佈</CardTitle>
                <CardDescription>過去24小時攻擊類型統計</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={attackTypeData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {attackTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>攻擊時間趨勢</CardTitle>
                <CardDescription>過去24小時攻擊趨勢分析</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsLineChart data={timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="attacks" stroke="#ef4444" strokeWidth={2} name="攻擊次數" />
                      <Line type="monotone" dataKey="blocked" stroke="#22c55e" strokeWidth={2} name="阻擋次數" />
                    </RechartsLineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>地理分佈分析</CardTitle>
              <CardDescription>攻擊來源地理位置統計</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {geoData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Globe className="h-5 w-5 text-blue-500" />
                      <div>
                        <p className="font-medium">{item.country}</p>
                        <p className="text-sm text-muted-foreground">{item.attacks} 次攻擊</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${item.percentage}%` }}></div>
                      </div>
                      <span className="text-sm font-medium w-12">{item.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 關聯分析 */}
        <TabsContent value="correlation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="h-5 w-5" style={{ color: "#0D99FF" }} />
                攻擊關聯分析
              </CardTitle>
              <CardDescription>分析攻擊模式和關聯性，識別潛在威脅</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">IP地址關聯</h3>
                  <div className="space-y-3">
                    <div className="p-4 border rounded-lg bg-red-50 dark:bg-red-950/30">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-mono text-sm">192.168.1.100</span>
                        <Badge variant="destructive">高風險</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">過去24小時內發起了 15 次不同類型的攻擊</p>
                      <div className="flex gap-2">
                        <Badge variant="outline" className="text-xs">
                          SQL注入
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          XSS攻擊
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          目錄遍歷
                        </Badge>
                      </div>
                    </div>

                    <div className="p-4 border rounded-lg bg-orange-50 dark:bg-orange-950/30">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-mono text-sm">203.0.113.45</span>
                        <Badge variant="secondary">中風險</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">集中攻擊特定端點，疑似自動化工具</p>
                      <div className="flex gap-2">
                        <Badge variant="outline" className="text-xs">
                          XSS攻擊
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          CSRF
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">攻擊模式分析</h3>
                  <div className="space-y-3">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="h-4 w-4 text-blue-500" />
                        <span className="font-medium">協調攻擊模式</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">檢測到來自多個IP的協調攻擊，時間間隔規律</p>
                      <div className="text-xs text-muted-foreground">
                        涉及IP: 5個 | 時間窗口: 30分鐘 | 攻擊次數: 45次
                      </div>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Activity className="h-4 w-4 text-orange-500" />
                        <span className="font-medium">漸進式攻擊</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">攻擊者先進行偵察，然後逐步升級攻擊強度</p>
                      <div className="text-xs text-muted-foreground">階段: 偵察 → 漏洞掃描 → 攻擊嘗試 → 權限提升</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">威脅情報關聯</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="border-red-200 bg-red-50 dark:bg-red-950/30">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="h-4 w-4 text-red-500" />
                        <span className="font-medium text-red-700 dark:text-red-300">已知惡意IP</span>
                      </div>
                      <p className="text-sm text-red-600 dark:text-red-400">3個IP地址匹配威脅情報數據庫</p>
                    </CardContent>
                  </Card>

                  <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/30">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Shield className="h-4 w-4 text-orange-500" />
                        <span className="font-medium text-orange-700 dark:text-orange-300">可疑行為</span>
                      </div>
                      <p className="text-sm text-orange-600 dark:text-orange-400">7個IP顯示異常行為模式</p>
                    </CardContent>
                  </Card>

                  <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950/30">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Globe className="h-4 w-4 text-blue-500" />
                        <span className="font-medium text-blue-700 dark:text-blue-300">地理異常</span>
                      </div>
                      <p className="text-sm text-blue-600 dark:text-blue-400">檢測到來自高風險地區的攻擊</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">建議措施</h3>
                <div className="space-y-3">
                  <div className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-950/30">
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="h-4 w-4 text-blue-500" />
                      <span className="font-medium">立即措施</span>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• 將高風險IP地址 192.168.1.100 加入黑名單</li>
                      <li>• 加強對 /api/users 端點的監控</li>
                      <li>• 啟用更嚴格的速率限制規則</li>
                    </ul>
                  </div>

                  <div className="p-4 border rounded-lg bg-green-50 dark:bg-green-950/30">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="h-4 w-4 text-green-500" />
                      <span className="font-medium">長期優化</span>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• 更新WAF規則以應對新的攻擊模式</li>
                      <li>• 實施地理位置阻擋策略</li>
                      <li>• 加強應用程序輸入驗證</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* HTTP流量分析 */}
        <TabsContent value="traffic-analysis" className="space-y-6">
          {/* 流量統計概覽 */}
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">總請求數</p>
                    <p className="text-2xl font-bold">{trafficStats.totalRequests.toLocaleString()}</p>
                  </div>
                  <Server className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">獨立訪客</p>
                    <p className="text-2xl font-bold">{trafficStats.uniqueVisitors.toLocaleString()}</p>
                  </div>
                  <Users className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">總流量</p>
                    <p className="text-2xl font-bold">{trafficStats.bandwidth}</p>
                  </div>
                  <Activity className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">平均響應時間</p>
                    <p className="text-2xl font-bold">{trafficStats.avgResponseTime}</p>
                  </div>
                  <Clock className="h-8 w-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">成功率</p>
                    <p className="text-2xl font-bold text-green-600">{trafficStats.successRate}%</p>
                  </div>
                  <MousePointer className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">錯誤率</p>
                    <p className="text-2xl font-bold text-red-600">{trafficStats.errorRate}%</p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-red-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 時間範圍選擇器 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" style={{ color: "#0D99FF" }} />
                流量分析時間範圍
              </CardTitle>
              <CardDescription>選擇要分析的時間範圍（最多30天）</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="space-y-2">
                  <Label>時間範圍</Label>
                  <Select value={trafficTimeRange} onValueChange={setTrafficTimeRange}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="24h">過去24小時</SelectItem>
                      <SelectItem value="7d">過去7天</SelectItem>
                      <SelectItem value="14d">過去14天</SelectItem>
                      <SelectItem value="30d">過去30天</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button variant="outline" size="sm" className="mt-6 bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  導出報表
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* 1. 整體HTTP流量統計 */}
          <Card>
            <CardHeader>
              <CardTitle>整體HTTP流量趨勢</CardTitle>
              <CardDescription>
                過去
                {trafficTimeRange === "24h"
                  ? "24小時"
                  : trafficTimeRange === "7d"
                    ? "7天"
                    : trafficTimeRange === "14d"
                      ? "14天"
                      : "30天"}
                的流量變化趨勢
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsAreaChart data={httpTrafficData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Area
                      yAxisId="left"
                      type="monotone"
                      dataKey="requests"
                      stackId="1"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.6}
                      name="請求數"
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="visitors"
                      stroke="#10b981"
                      strokeWidth={2}
                      name="獨立訪客"
                    />
                  </RechartsAreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* 2. 子網域流量分析 */}
          <Card>
            <CardHeader>
              <CardTitle>子網域流量分析</CardTitle>
              <CardDescription>各子網域的流量分佈和使用情況</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {subdomainData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Globe className="h-5 w-5 text-blue-500" />
                      <div>
                        <p className="font-medium font-mono">{item.subdomain}</p>
                        <p className="text-sm text-muted-foreground">
                          {item.requests.toLocaleString()} 請求 • {item.bandwidth} 流量
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${item.percentage}%` }}></div>
                      </div>
                      <span className="text-sm font-medium w-12">{item.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 3. HTTP回應狀態統計 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>HTTP狀態碼分佈</CardTitle>
                <CardDescription>HTTP回應狀態碼統計</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={httpStatusData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="count"
                        label={({ status, percentage }) => `${status}: ${percentage}%`}
                      >
                        {httpStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [value.toLocaleString(), "請求數"]} />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>狀態碼詳細統計</CardTitle>
                <CardDescription>各狀態碼的詳細數據</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {httpStatusData.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 rounded" style={{ backgroundColor: item.color }}></div>
                        <div>
                          <p className="font-medium">
                            {item.status} - {item.name}
                          </p>
                          <p className="text-sm text-muted-foreground">{item.count.toLocaleString()} 次</p>
                        </div>
                      </div>
                      <span className="text-sm font-medium">{item.percentage}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 4. 依據地區的請求量 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" style={{ color: "#0D99FF" }} />
                地區請求量分析
              </CardTitle>
              <CardDescription>按地理位置統計的請求量分佈</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  {regionRequestData.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{item.flag}</span>
                        <div>
                          <p className="font-medium">{item.country}</p>
                          <p className="text-sm text-muted-foreground">
                            {item.region} • {item.requests.toLocaleString()} 請求
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div className="bg-green-600 h-2 rounded-full" style={{ width: `${item.percentage}%` }}></div>
                        </div>
                        <span className="text-sm font-medium w-12">{item.percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart data={regionRequestData} layout="horizontal">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="country" type="category" width={80} />
                      <Tooltip formatter={(value) => [value.toLocaleString(), "請求數"]} />
                      <Bar dataKey="requests" fill="#10b981" />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 5. 來源ASN */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" style={{ color: "#0D99FF" }} />
                來源ASN分析
              </CardTitle>
              <CardDescription>按自治系統號碼(ASN)統計的請求來源</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ASN</TableHead>
                    <TableHead>組織名稱</TableHead>
                    <TableHead>國家</TableHead>
                    <TableHead>請求數</TableHead>
                    <TableHead>佔比</TableHead>
                    <TableHead>流量分佈</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {asnData.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-mono">{item.asn}</TableCell>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{item.country}</TableCell>
                      <TableCell>{item.requests.toLocaleString()}</TableCell>
                      <TableCell>{item.percentage}%</TableCell>
                      <TableCell>
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full"
                            style={{ width: `${item.percentage}%` }}
                          ></div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* 6. 來源IP */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="h-5 w-5" style={{ color: "#0D99FF" }} />
                來源IP分析
              </CardTitle>
              <CardDescription>請求量最高的來源IP地址統計</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>IP地址</TableHead>
                    <TableHead>請求數</TableHead>
                    <TableHead>國家</TableHead>
                    <TableHead>城市</TableHead>
                    <TableHead>ASN</TableHead>
                    <TableHead>狀態</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sourceIPData.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-mono">{item.ip}</TableCell>
                      <TableCell className="font-medium">{item.requests.toLocaleString()}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Globe className="h-4 w-4 text-muted-foreground" />
                          {item.country}
                        </div>
                      </TableCell>
                      <TableCell>{item.city}</TableCell>
                      <TableCell className="font-mono text-sm">{item.asn}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-green-600 bg-green-50 border-green-200">
                          正常
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 日誌詳情對話框 */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>安全事件詳情</DialogTitle>
            <DialogDescription>事件ID: {selectedLogDetail?.id}</DialogDescription>
          </DialogHeader>

          {selectedLogDetail && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm font-medium">時間戳</Label>
                    <p className="font-mono text-sm">{selectedLogDetail.timestamp}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">嚴重程度</Label>
                    <Badge variant="outline" className={getSeverityColor(selectedLogDetail.severity)}>
                      {selectedLogDetail.severity}
                    </Badge>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">攻擊類型</Label>
                    <p className="font-medium">{selectedLogDetail.type}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">規則ID</Label>
                    <p className="font-mono text-sm">{selectedLogDetail.ruleId}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <Label className="text-sm font-medium">來源IP</Label>
                    <p className="font-mono text-sm">{selectedLogDetail.sourceIP}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">目標URL</Label>
                    <p className="font-mono text-sm break-all">{selectedLogDetail.targetURL}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">處理動作</Label>
                    <Badge variant="outline" className={getActionColor(selectedLogDetail.action)}>
                      {selectedLogDetail.action}
                    </Badge>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">國家/地區</Label>
                    <p>{selectedLogDetail.country}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium">User Agent</Label>
                <p className="font-mono text-sm bg-muted p-2 rounded break-all">{selectedLogDetail.userAgent}</p>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium">攻擊詳情</Label>
                <div className="bg-muted p-4 rounded-lg">
                  <pre className="text-sm whitespace-pre-wrap">
                    {JSON.stringify(selectedLogDetail.details, null, 2)}
                  </pre>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
